f = input('Enter the temperature in Fahrenheit: ')
c = 5/9 * (float(f) - 32)
print(f, 'degrees F is', c, 'degrees C')

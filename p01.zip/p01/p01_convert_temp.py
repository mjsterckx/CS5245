f = float(input('Enter the temperature in Fahrenheit: '))
c = 5/9 * (f - 32)
print(str(f), 'degrees F is', str(c), 'degrees C')
